<?php

return [
    'home' => 'Home',
    'account' => [
        'header' => 'Conta,
        'my_account' => 'Minha Conta',
        'security_controls' => 'Controle De Segurança',
        'api_access' => 'Api Da Conta',
        'my_servers' => 'Meus Servidores',
    ],
    'server' => [
        'header' => 'CONFIGURAÇÃODE SERVIDOR',
        'console' => 'Console',
        'console-pop' => 'Fullscreen Console',
        'file_management' => 'ARQUIVOS',
        'file_browser' => 'Navegando Arquivos',
        'create_file' => 'Create File',
        'upload_files' => 'Upload Files',
        'subusers' => 'Sub Usuario',
        'schedules' => 'Schedules',
        'configuration' => 'Configuration',
        'port_allocations' => 'Configuração de Alocação',
        'sftp_settings' => 'Configuração de SFTP',
        'startup_parameters' => 'Inicialização',
        'databases' => 'Databases',
        'edit_file' => 'Edit File',
        'admin_header' => 'ADMINISTRATIVE',
        'admin' => 'Configuraçao De Servidor',
        'server_name' => 'Nome Do Servidor',
    ],
];
